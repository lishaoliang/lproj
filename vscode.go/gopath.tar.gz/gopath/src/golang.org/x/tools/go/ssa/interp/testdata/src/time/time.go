package time

type Duration int64

func Sleep(Duration)
