//+build !go1.11

package lsp

func init() {
	goVersion111 = false
}
